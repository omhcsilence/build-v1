#!/bin/bash
# ============================================================
# YakuzaXsilence Flutter APK Build Script v13
# Auto-setup: JDK 17, Android SDK, Flutter SDK, NDK
# Debug signing -- no keystore needed
# v13: RAM detection, auto-swap, Gradle memory tuning
# ============================================================

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

echo -e "${CYAN}${BOLD}+==========================================+${NC}"
echo -e "${CYAN}${BOLD}|  YakuzaXsilence Build v13 (Auto-Setup)   |${NC}"
echo -e "${CYAN}${BOLD}+==========================================+${NC}"
echo ""

# ──────────────────────────────────────────────
# Config
# ──────────────────────────────────────────────
FLUTTER_VERSION="3.44.0"
ANDROID_SDK_DIR="$HOME/android-sdk"
FLUTTER_DIR="$HOME/flutter"
REQUIRED_NDK="28.2.13676358"
REQUIRED_COMPILE_SDK=36
REQUIRED_TARGET_SDK=36

# cmdline-tools versions to try (newest first)
CMDLINE_VERSIONS=("9123335" "8512546")

# ──────────────────────────────────────────────
# Step 0: Pre-flight
# ──────────────────────────────────────────────
echo -e "${CYAN}[0/9] Pre-flight checks...${NC}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

if [ ! -f "pubspec.yaml" ]; then
    echo -e "${RED}ERROR: pubspec.yaml not found in ${SCRIPT_DIR}${NC}"
    exit 1
fi

echo -e "  Project: ${GREEN}$(grep '^name:' pubspec.yaml | head -1)${NC}"
echo -e "  Version: ${GREEN}$(grep '^version:' pubspec.yaml | head -1)${NC}"

# Fix git safe.directory for root user (common on VPS)
if [ "$(id -u)" -eq 0 ]; then
    echo -e "  ${YELLOW}Running as root — adding git safe.directory exceptions${NC}"
    git config --global --add safe.directory "$FLUTTER_DIR" 2>/dev/null || true
    git config --global --add safe.directory "$SCRIPT_DIR" 2>/dev/null || true
    # Wildcard — allow all directories (safe for CI/VPS builds)
    git config --global --add safe.directory "*" 2>/dev/null || true
fi

echo ""

# ──────────────────────────────────────────────
# Step 1: RAM detection & swap
# ──────────────────────────────────────────────
echo -e "${CYAN}[1/9] Checking system memory...${NC}"

# Get total RAM in MB
TOTAL_RAM_MB=$(grep MemTotal /proc/meminfo | awk '{print int($2/1024)}')
echo -e "  Total RAM: ${GREEN}${TOTAL_RAM_MB} MB${NC}"

# Determine Gradle heap based on available RAM
if [ "$TOTAL_RAM_MB" -ge 16000 ]; then
    GRADLE_HEAP="8G"
    GRADLE_META="2G"
    echo -e "  ${GREEN}Plenty of RAM — Gradle heap: 8G${NC}"
elif [ "$TOTAL_RAM_MB" -ge 8000 ]; then
    GRADLE_HEAP="4G"
    GRADLE_META="1G"
    echo -e "  ${GREEN}8GB+ RAM — Gradle heap: 4G${NC}"
elif [ "$TOTAL_RAM_MB" -ge 4000 ]; then
    GRADLE_HEAP="2G"
    GRADLE_META="512m"
    echo -e "  ${YELLOW}4GB+ RAM — Gradle heap: 2G (may be slow)${NC}"
else
    GRADLE_HEAP="1G"
    GRADLE_META="256m"
    echo -e "  ${YELLOW}Low RAM — Gradle heap: 1G (will be slow)${NC}"
fi

# Check existing swap
CURRENT_SWAP_MB=$(grep SwapTotal /proc/meminfo | awk '{print int($2/1024)}')
echo -e "  Current swap: ${GREEN}${CURRENT_SWAP_MB} MB${NC}"

# Create swap if needed (min 4GB total virtual memory for build)
NEED_SWAP=false
TOTAL_VIRTUAL=$((TOTAL_RAM_MB + CURRENT_SWAP_MB))

if [ "$TOTAL_VIRTUAL" -lt 4096 ]; then
    NEED_SWAP=true
    SWAP_SIZE_MB=$((4096 - TOTAL_VIRTUAL + 1024))  # add 1GB buffer
elif [ "$TOTAL_RAM_MB" -lt 40192 ] && [ "$CURRENT_SWAP_MB" -lt 2048 ]; then
    NEED_SWAP=true
    SWAP_SIZE_MB=2048
fi

if [ "$NEED_SWAP" = true ]; then
    echo -e "  ${YELLOW}Creating ${SWAP_SIZE_MB}MB swap file...${NC}"
    SWAP_FILE="/swapfile_build"
    if [ ! -f "$SWAP_FILE" ]; then
        dd if=/dev/zero of="$SWAP_FILE" bs=1M count="$SWAP_SIZE_MB" status=progress 2>&1 || true
        chmod 600 "$SWAP_FILE"
        mkswap "$SWAP_FILE" 2>/dev/null || true
        swapon "$SWAP_FILE" 2>/dev/null || true
        echo -e "  ${GREEN}Swap created and activated${NC}"
    else
        # Check if already active
        if ! swapon --show | grep -q "$SWAP_FILE"; then
            swapon "$SWAP_FILE" 2>/dev/null || true
        fi
        echo -e "  ${GREEN}Swap file already exists${NC}"
    fi
fi

# Write gradle.properties with tuned memory
GRADLE_PROPS="android/app/../../android/gradle.properties"
GRADLE_PROPS_PATH="android/gradle.properties"
echo -e "  ${YELLOW}Writing gradle.properties with Gradle heap: ${GRADLE_HEAP}${NC}"
cat > "$GRADLE_PROPS_PATH" << GRADLE_EOF
org.gradle.jvmargs=-Xmx${GRADLE_HEAP} -XX:MaxMetaspaceSize=${GRADLE_META} -XX:ReservedCodeCacheSize=256m
org.gradle.daemon=true
org.gradle.parallel=true
org.gradle.caching=true
android.useAndroidX=true
android.enableJetifier=true
GRADLE_EOF

echo -e "  ${GREEN}gradle.properties tuned for this server${NC}"
echo ""

# ──────────────────────────────────────────────
# Step 2: Install JDK 17
# ──────────────────────────────────────────────
echo -e "${CYAN}[2/9] Checking JDK 17...${NC}"

if java -version 2>&1 | grep -q "17"; then
    echo -e "  ${GREEN}JDK 17 already installed${NC}"
else
    echo -e "  ${YELLOW}JDK 17 not found, installing...${NC}"
    if command -v apt-get &> /dev/null; then
        apt-get update -qq 2>/dev/null || true
        apt-get install -y -qq openjdk-17-jdk-headless 2>/dev/null || true
    elif command -v yum &> /dev/null; then
        yum install -y java-17-openjdk-devel 2>/dev/null || true
    fi

    if java -version 2>&1 | grep -q "17"; then
        echo -e "  ${GREEN}JDK 17 installed via package manager${NC}"
    else
        echo -e "  ${YELLOW}Package manager failed, downloading Adoptium JDK...${NC}"
        TMP_JDK="/tmp/jdk17install"
        rm -rf "$TMP_JDK"
        mkdir -p "$TMP_JDK"
        curl -fSL "https://api.adoptium.net/v3/binary/latest/17/ga/linux/x64/jdk/hotspot/normal/eclipse" -o "$TMP_JDK/jdk17.tar.gz"
        tar -xzf "$TMP_JDK/jdk17.tar.gz" -C "$TMP_JDK"
        JDK_EXTRACTED=$(find "$TMP_JDK" -maxdepth 1 -type d -name "jdk-*" | head -1)
        if [ -n "$JDK_EXTRACTED" ]; then
            rm -rf /opt/jdk-17
            mv "$JDK_EXTRACTED" /opt/jdk-17
            export JAVA_HOME=/opt/jdk-17
            export PATH="/opt/jdk-17/bin:$PATH"
            if ! grep -q "jdk-17" "$HOME/.bashrc" 2>/dev/null; then
                echo 'export JAVA_HOME=/opt/jdk-17' >> "$HOME/.bashrc"
                echo 'export PATH=$JAVA_HOME/bin:$PATH' >> "$HOME/.bashrc"
            fi
            echo -e "  ${GREEN}JDK 17 installed at /opt/jdk-17${NC}"
        else
            echo -e "${RED}ERROR: Failed to install JDK 17${NC}"
            exit 1
        fi
        rm -rf "$TMP_JDK"
    fi
fi

# Set JAVA_HOME if not set
if [ -z "$JAVA_HOME" ]; then
    JAVA_BIN_PATH=$(readlink -f "$(which java)" 2>/dev/null || echo "")
    if [ -n "$JAVA_BIN_PATH" ]; then
        JAVA_BIN_DIR=$(dirname "$JAVA_BIN_PATH")
        export JAVA_HOME=$(dirname "$JAVA_BIN_DIR")
    fi
fi
echo -e "  JAVA_HOME = ${GREEN}${JAVA_HOME}${NC}"
echo ""

# ──────────────────────────────────────────────
# Step 3: Install Android SDK command-line tools
# ──────────────────────────────────────────────
echo -e "${CYAN}[3/9] Checking Android SDK...${NC}"

export ANDROID_HOME="$ANDROID_SDK_DIR"
export ANDROID_SDK_ROOT="$ANDROID_SDK_DIR"

if [ -f "$ANDROID_SDK_DIR/cmdline-tools/latest/bin/sdkmanager" ]; then
    echo -e "  ${GREEN}Android SDK cmdline-tools found${NC}"
else
    echo -e "  ${YELLOW}Android SDK not found, installing...${NC}"
    mkdir -p "$ANDROID_SDK_DIR/cmdline-tools"

    CMDLINE_DOWNLOADED=false
    for VER in "${CMDLINE_VERSIONS[@]}"; do
        CMDLINE_URL="https://dl.google.com/android/repository/commandlinetools-linux-${VER}_latest.zip"
        echo -e "  ${YELLOW}Trying cmdline-tools v${VER}...${NC}"
        HTTP_CODE=$(curl -sIo /dev/null -w "%{http_code}" "$CMDLINE_URL" 2>/dev/null || echo "000")
        if [ "$HTTP_CODE" = "200" ]; then
            CMDLINE_ZIP="/tmp/commandlinetools.zip"
            curl -fSL "$CMDLINE_URL" -o "$CMDLINE_ZIP"
            TMP_EXTRACT="/tmp/cmdline-tools-tmp"
            rm -rf "$TMP_EXTRACT"
            mkdir -p "$TMP_EXTRACT"
            unzip -q "$CMDLINE_ZIP" -d "$TMP_EXTRACT"
            if [ -d "$TMP_EXTRACT/cmdline-tools" ]; then
                mv "$TMP_EXTRACT/cmdline-tools" "$ANDROID_SDK_DIR/cmdline-tools/latest"
                CMDLINE_DOWNLOADED=true
            fi
            rm -rf "$TMP_EXTRACT" "$CMDLINE_ZIP"
            break
        else
            echo -e "  ${YELLOW}v${VER} returned HTTP ${HTTP_CODE}, trying next...${NC}"
        fi
    done

    if [ "$CMDLINE_DOWNLOADED" = true ] && [ -f "$ANDROID_SDK_DIR/cmdline-tools/latest/bin/sdkmanager" ]; then
        echo -e "  ${GREEN}Android cmdline-tools installed${NC}"
    else
        echo -e "${RED}ERROR: Could not download Android cmdline-tools${NC}"
        echo -e "${RED}Please install manually from https://developer.android.com/studio#command-line-tools-only${NC}"
        exit 1
    fi
fi

export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH"

if ! grep -q "ANDROID_HOME" "$HOME/.bashrc" 2>/dev/null; then
    echo "export ANDROID_HOME=$ANDROID_SDK_DIR" >> "$HOME/.bashrc"
    echo "export ANDROID_SDK_ROOT=$ANDROID_SDK_DIR" >> "$HOME/.bashrc"
fi

echo ""

# ──────────────────────────────────────────────
# Step 4: Install Android SDK components
# ──────────────────────────────────────────────
echo -e "${CYAN}[4/9] Installing SDK components...${NC}"

SDKMANAGER="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"

# Accept licenses first
yes | "$SDKMANAGER" --licenses > /dev/null 2>&1 || true

echo -e "  Installing platforms;android-${REQUIRED_COMPILE_SDK}..."
yes | "$SDKMANAGER" --install "platforms;android-${REQUIRED_COMPILE_SDK}" > /dev/null 2>&1 || true

echo -e "  Installing build-tools;${REQUIRED_COMPILE_SDK}.0..."
yes | "$SDKMANAGER" --install "build-tools;${REQUIRED_COMPILE_SDK}.0" > /dev/null 2>&1 || true

echo -e "  Installing platform-tools..."
yes | "$SDKMANAGER" --install "platform-tools" > /dev/null 2>&1 || true

echo -e "  Installing ndk;${REQUIRED_NDK}..."
yes | "$SDKMANAGER" --install "ndk;${REQUIRED_NDK}" > /dev/null 2>&1 || true

echo -e "  ${GREEN}SDK components ready${NC}"
echo ""

# ──────────────────────────────────────────────
# Step 5: Install Flutter SDK
# ──────────────────────────────────────────────
echo -e "${CYAN}[5/9] Checking Flutter SDK...${NC}"

FLUTTER_BIN=""
if command -v flutter &> /dev/null; then
    FLUTTER_BIN="$(command -v flutter)"
    echo -e "  ${GREEN}Flutter found: ${FLUTTER_BIN}${NC}"
elif [ -f "$FLUTTER_DIR/bin/flutter" ]; then
    FLUTTER_BIN="$FLUTTER_DIR/bin/flutter"
    echo -e "  ${GREEN}Flutter found: ${FLUTTER_BIN}${NC}"
fi

if [ -z "$FLUTTER_BIN" ]; then
    echo -e "  ${YELLOW}Flutter not found, installing ${FLUTTER_VERSION}...${NC}"

    # Install dependencies first
    if command -v apt-get &> /dev/null; then
        apt-get update -qq 2>/dev/null || true
        apt-get install -y -qq git curl unzip xz-utils zip clang cmake ninja-build pkg-config libgtk-3-dev 2>/dev/null || true
    elif command -v yum &> /dev/null; then
        yum install -y git curl unzip xz zip 2>/dev/null || true
    fi

    FLUTTER_URL="https://storage.googleapis.com/flutter_infra_release/releases/stable/linux/flutter_linux_${FLUTTER_VERSION}-stable.tar.xz"
    echo -e "  ${YELLOW}Downloading Flutter ${FLUTTER_VERSION}...${NC}"
    curl -fSL "$FLUTTER_URL" -o "/tmp/flutter.tar.xz"

    echo -e "  ${YELLOW}Extracting to ${FLUTTER_DIR}...${NC}"
    rm -rf "$FLUTTER_DIR"
    tar -xf "/tmp/flutter.tar.xz" -C "$HOME"
    rm -f "/tmp/flutter.tar.xz"

    FLUTTER_BIN="$FLUTTER_DIR/bin/flutter"

    # Fix git safe.directory for newly installed Flutter
    git config --global --add safe.directory "$FLUTTER_DIR" 2>/dev/null || true
    git config --global --add safe.directory "*" 2>/dev/null || true

    if ! grep -q "flutter/bin" "$HOME/.bashrc" 2>/dev/null; then
        echo "export PATH=$FLUTTER_DIR/bin:\$PATH" >> "$HOME/.bashrc"
    fi

    echo -e "  ${GREEN}Flutter ${FLUTTER_VERSION} installed${NC}"
fi

export PATH="$(dirname "$FLUTTER_BIN"):$PATH"

echo -e "  ${YELLOW}Running flutter doctor...${NC}"
"$FLUTTER_BIN" doctor 2>&1 | head -25 || true
echo ""

# ──────────────────────────────────────────────
# Step 6: Auto-fix build.gradle.kts
# ──────────────────────────────────────────────
echo -e "${CYAN}[6/9] Validating build.gradle.kts...${NC}"

GRADLE_FILE="android/app/build.gradle.kts"
if [ ! -f "$GRADLE_FILE" ]; then
    echo -e "${RED}ERROR: ${GRADLE_FILE} not found!${NC}"
    exit 1
fi

# compileSdk
CS=$(grep -oP 'compileSdk\s*=\s*\K\d+' "$GRADLE_FILE" 2>/dev/null || echo "")
if [ "$CS" = "$REQUIRED_COMPILE_SDK" ]; then
    echo -e "  ${GREEN}compileSdk = ${REQUIRED_COMPILE_SDK} OK${NC}"
else
    echo -e "  ${YELLOW}Fixing compileSdk -> ${REQUIRED_COMPILE_SDK}${NC}"
    sed -i "s/compileSdk\s*=\s*[0-9]\+/compileSdk = ${REQUIRED_COMPILE_SDK}/" "$GRADLE_FILE"
fi

# targetSdk
TS=$(grep -oP 'targetSdk\s*=\s*\K\d+' "$GRADLE_FILE" 2>/dev/null || echo "")
if [ "$TS" = "$REQUIRED_TARGET_SDK" ]; then
    echo -e "  ${GREEN}targetSdk = ${REQUIRED_TARGET_SDK} OK${NC}"
else
    echo -e "  ${YELLOW}Fixing targetSdk -> ${REQUIRED_TARGET_SDK}${NC}"
    sed -i "s/targetSdk\s*=\s*[0-9]\+/targetSdk = ${REQUIRED_TARGET_SDK}/" "$GRADLE_FILE"
fi

# ndkVersion
if grep -q 'ndkVersion' "$GRADLE_FILE"; then
    NK=$(grep -oP 'ndkVersion\s*=\s*"\K[^"]+' "$GRADLE_FILE" 2>/dev/null || echo "")
    if [ "$NK" = "$REQUIRED_NDK" ]; then
        echo -e "  ${GREEN}ndkVersion = ${REQUIRED_NDK} OK${NC}"
    else
        echo -e "  ${YELLOW}Fixing ndkVersion -> ${REQUIRED_NDK}${NC}"
        sed -i "s/ndkVersion\s*=\s*\"[^\"]*\"/ndkVersion = \"${REQUIRED_NDK}\"/" "$GRADLE_FILE"
    fi
else
    echo -e "  ${YELLOW}Adding ndkVersion${NC}"
    sed -i "/compileSdk = ${REQUIRED_COMPILE_SDK}/a\\    ndkVersion = \"${REQUIRED_NDK}\"" "$GRADLE_FILE"
fi

# Ensure debug signing for release (no keystore needed)
if grep -q 'storeFile' "$GRADLE_FILE"; then
    echo -e "  ${YELLOW}Switching to debug signing (no keystore)${NC}"
    # Remove signingConfigs block entirely
    sed -i '/signingConfigs {/,/^    }/d' "$GRADLE_FILE"
    # Change release signing to debug
    sed -i 's/signingConfigs.getByName("release")/signingConfigs.getByName("debug")/' "$GRADLE_FILE"
fi

echo -e "  ${GREEN}build.gradle.kts OK${NC}"
echo ""

# ──────────────────────────────────────────────
# Step 7: Write local.properties
# ──────────────────────────────────────────────
echo -e "${CYAN}[7/9] Writing local.properties...${NC}"

FLUTTER_SDK_ROOT=$(dirname "$(dirname "$FLUTTER_BIN")")

# Use printf to avoid heredoc issues
printf 'sdk.dir=%s\nflutter.sdk=%s\n' "$ANDROID_HOME" "$FLUTTER_SDK_ROOT" > android/local.properties

echo -e "  ${GREEN}local.properties written${NC}"
echo -e "  sdk.dir     = ${GREEN}${ANDROID_HOME}${NC}"
echo -e "  flutter.sdk = ${GREEN}${FLUTTER_SDK_ROOT}${NC}"
echo ""

# ──────────────────────────────────────────────
# Step 8: Clean + get dependencies
# ──────────────────────────────────────────────
echo -e "${CYAN}[8/9] Clean & get dependencies...${NC}"

"$FLUTTER_BIN" clean
"$FLUTTER_BIN" pub get
echo ""

# ──────────────────────────────────────────────
# Step 9: Build APK
# ──────────────────────────────────────────────
echo -e "${CYAN}[9/9] Building release APK (debug signing)...${NC}"
echo -e "  ${YELLOW}Gradle heap: ${GRADLE_HEAP} | This may take several minutes...${NC}"

# Kill any stale Gradle daemons from previous runs
cd android
./gradlew --stop 2>/dev/null || true
cd "$SCRIPT_DIR"

BUILD_START=$(date +%s)

if "$FLUTTER_BIN" build apk --release --android-skip-build-dependency-validation; then
    BUILD_END=$(date +%s)
    DUR=$((BUILD_END - BUILD_START))
    echo ""
    echo -e "${GREEN}+==========================================+${NC}"
    echo -e "${GREEN}|         BUILD SUCCESSFUL!                |${NC}"
    echo -e "${GREEN}+==========================================+${NC}"

    APK_PATH="build/app/outputs/flutter-apk/app-release.apk"
    if [ -f "$APK_PATH" ]; then
        APK_SIZE=$(du -h "$APK_PATH" | cut -f1)
        echo -e "  ${GREEN}APK:${NC}    ${APK_PATH}"
        echo -e "  ${GREEN}Size:${NC}   ${APK_SIZE}"
        echo -e "  ${GREEN}Time:${NC}   $((DUR/60))m $((DUR%60))s"
    fi
else
    BUILD_END=$(date +%s)
    DURF=$((BUILD_END - BUILD_START))
    echo ""
    echo -e "${RED}+==========================================+${NC}"
    echo -e "${RED}|         BUILD FAILED!                    |${NC}"
    echo -e "${RED}+==========================================+${NC}"
    echo -e "  ${RED}Failed after $((DURF/60))m $((DURF%60))s${NC}"
    echo ""
    echo -e "  ${YELLOW}Tips:${NC}"
    echo -e "    - Check if OOM: dmesg | grep -i 'oom kill'"
    echo -e "    - Free memory: free -h"
    echo -e "    - Debug build: flutter build apk --release --verbose"
    exit 1
fi

echo ""
echo -e "${CYAN}=== Build Script Complete ===${NC}"
