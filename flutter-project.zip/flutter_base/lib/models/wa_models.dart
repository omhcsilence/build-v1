// lib/models/wa_models.dart
// Models for the WhatsApp-based private chat system.

class WAContact {
  final String jid;
  final String name;
  final String? verifiedName;
  final String? picUrl;

  WAContact({required this.jid, required this.name, this.verifiedName, this.picUrl});

  factory WAContact.fromMap(Map<String, dynamic> m) => WAContact(
        jid: m['jid']?.toString() ?? '',
        name: m['name']?.toString() ?? m['jid'].toString().split('@').first,
        verifiedName: m['verifiedName']?.toString() == 'null' ? null : m['verifiedName']?.toString(),
        picUrl: m['picUrl']?.toString() == 'null' ? null : m['picUrl']?.toString(),
      );

  String get phone => jid.split('@').first;
  bool get isGroup => jid.endsWith('@g.us');
  bool get isBroadcast => jid == 'status@broadcast';
}

enum WAMessageType { text, image, voice, video, document, sticker, unknown }

class WAMessage {
  final String id;
  final String from;
  final bool fromMe;
  final WAMessageType type;
  final String text;
  final String caption;
  final int durationMs;
  final DateTime time;

  WAMessage({
    required this.id,
    required this.from,
    required this.fromMe,
    required this.type,
    required this.text,
    this.caption = '',
    this.durationMs = 0,
    required this.time,
  });

  factory WAMessage.fromMap(Map<String, dynamic> m) {
    final typeStr = (m['type'] ?? 'text').toString().toLowerCase();
    WAMessageType mt;
    switch (typeStr) {
      case 'image':       mt = WAMessageType.image; break;
      case 'voice':       mt = WAMessageType.voice; break;
      case 'video':       mt = WAMessageType.video; break;
      case 'document':   mt = WAMessageType.document; break;
      case 'sticker':     mt = WAMessageType.sticker; break;
      case 'unknown':    mt = WAMessageType.unknown; break;
      default:            mt = WAMessageType.text;
    }
    return WAMessage(
      id: m['id']?.toString() ?? '',
      from: m['from']?.toString() ?? '',
      fromMe: m['fromMe'] == true,
      type: mt,
      text: (m['text'] ?? '').toString(),
      caption: (m['caption'] ?? '').toString(),
      durationMs: m['durationMs'] is num ? (m['durationMs'] as num).toInt() : 0,
      time: DateTime.tryParse(m['time']?.toString() ?? '') ?? DateTime.now(),
    );
  }

  String get preview {
    switch (type) {
      case WAMessageType.voice:    return '🎙️ Voice message';
      case WAMessageType.image:    return caption.isNotEmpty ? '📷 $caption' : '[Image]';
      case WAMessageType.video:    return caption.isNotEmpty ? '🎬 $caption' : '[Video]';
      case WAMessageType.document: return '[Document]';
      case WAMessageType.sticker:  return '[Sticker]';
      case WAMessageType.unknown:  return '[Unknown]';
      case WAMessageType.text:     return text;
    }
  }
}

class WAChatPreview {
  final String jid;
  final String name;
  final String lastMessage;
  final String? lastType;
  final DateTime? lastTime;
  final int unread;

  WAChatPreview({
    required this.jid,
    required this.name,
    required this.lastMessage,
    this.lastType,
    this.lastTime,
    this.unread = 0,
  });

  factory WAChatPreview.fromMap(Map<String, dynamic> m) => WAChatPreview(
        jid: m['jid']?.toString() ?? '',
        name: m['name']?.toString() ?? '',
        lastMessage: m['lastMessage']?.toString() ?? '',
        lastType: m['lastType']?.toString(),
        lastTime: m['lastTime'] != null ? DateTime.tryParse(m['lastTime'].toString()) : null,
        unread: m['unread'] is num ? (m['unread'] as num).toInt() : 0,
      );
}

class WAStatus {
  final String id;
  final String from;
  final String type;
  final String text;
  final DateTime time;

  WAStatus({
    required this.id,
    required this.from,
    required this.type,
    required this.text,
    required this.time,
  });

  factory WAStatus.fromMap(Map<String, dynamic> m) => WAStatus(
        id: m['id']?.toString() ?? '',
        from: m['from']?.toString() ?? '',
        type: m['type']?.toString() ?? 'text',
        text: m['text']?.toString() ?? '',
        time: DateTime.tryParse(m['time']?.toString() ?? '') ?? DateTime.now(),
      );
}

class WAPairingInfo {
  final String phone;
  final String jid;
  final String name;
  final String connectedAt;

  WAPairingInfo({required this.phone, required this.jid, required this.name, required this.connectedAt});

  factory WAPairingInfo.fromMap(Map<String, dynamic> m) => WAPairingInfo(
        phone: m['phone']?.toString() ?? '',
        jid: m['jid']?.toString() ?? '',
        name: m['name']?.toString() ?? '',
        connectedAt: m['connectedAt']?.toString() ?? '',
      );
}
