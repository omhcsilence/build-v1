// lib/screens/status_screen.dart
// View contacts' status updates + post your own (text/image/video).

import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../models/wa_models.dart';
import '../services/whatsapp_service.dart';

class StatusScreen extends StatefulWidget {
  final String sessionKey;
  final String baseUrl;

  StatusScreen({super.key, required this.sessionKey, required this.baseUrl});

  @override
  State<StatusScreen> createState() => _StatusScreenState();
}

class _StatusScreenState extends State<StatusScreen> {
  List<Map<String, dynamic>> _statusList = [];
  bool _loading = true;
  Timer? _refreshTimer;

  @override
  void initState() {
    super.initState();
    _fetchStatus();
    _refreshTimer = Timer.periodic(Duration(seconds: 10), (_) => _fetchStatus());
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    super.dispose();
  }

  Future<void> _fetchStatus() async {
    final list = await WhatsAppService.instance.getStatusList();
    if (mounted) {
      setState(() {
        _statusList = list;
        _loading = false;
      });
    }
  }

  Future<void> _postTextStatus() async {
    final text = await showDialog<String>(
      context: context,
      builder: (ctx) {
        final ctrl = TextEditingController();
        return AlertDialog(
          backgroundColor: Color(0xFF111111),
          title: Text('Post Text Status', style: TextStyle(color: Colors.white)),
          content: TextField(
            controller: ctrl,
            style: TextStyle(color: Colors.white),
            maxLines: 3,
            decoration: InputDecoration(
              hintText: 'Type your status...',
              hintStyle: TextStyle(color: Colors.white38),
              enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.white24)),
              focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.cyanAccent)),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: Text('Cancel')),
            ElevatedButton(
              onPressed: () => Navigator.pop(ctx, ctrl.text.trim()),
              child: Text('Post'),
            ),
          ],
        );
      },
    );
    if (text == null || text.isEmpty) return;
    final ok = await WhatsAppService.instance.postStatus(type: 'text', text: text);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(ok ? 'Status posted!' : 'Failed to post status'),
        backgroundColor: ok ? Colors.green : Colors.red,
      ));
      if (ok) _fetchStatus();
    }
  }

  Future<void> _postImageStatus() async {
    final picker = ImagePicker();
    final xfile = await picker.pickImage(source: ImageSource.gallery, imageQuality: 70, maxWidth: 1200);
    if (xfile == null) return;
    final bytes = await xfile.readAsBytes();
    final b64 = 'data:image/jpeg;base64,${base64Encode(bytes)}';
    final ok = await WhatsAppService.instance.postStatus(type: 'image', mediaBase64: b64);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(ok ? 'Status image posted!' : 'Failed to post image'),
        backgroundColor: ok ? Colors.green : Colors.red,
      ));
      if (ok) _fetchStatus();
    }
  }

  void _showPostOptions() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Color(0xFF111111),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(height: 12),
            ListTile(
              leading: Icon(Icons.text_fields, color: Colors.cyanAccent),
              title: Text('Text Status', style: TextStyle(color: Colors.white, fontFamily: 'ShareTechMono')),
              onTap: () { Navigator.pop(ctx); _postTextStatus(); },
            ),
            ListTile(
              leading: Icon(Icons.image, color: Colors.cyanAccent),
              title: Text('Image Status', style: TextStyle(color: Colors.white, fontFamily: 'ShareTechMono')),
              onTap: () { Navigator.pop(ctx); _postImageStatus(); },
            ),
            SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF070D17),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text('Status', style: TextStyle(color: Colors.white, fontFamily: 'MADEEvolveSansEVO')),
        iconTheme: IconThemeData(color: Colors.white),
        actions: [
          IconButton(
            icon: Icon(Icons.add_a_photo_outlined, color: Colors.cyanAccent),
            onPressed: _showPostOptions,
            tooltip: 'Post Status',
          ),
        ],
      ),
      body: _loading
          ? Center(child: CircularProgressIndicator(color: Colors.cyanAccent))
          : _statusList.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.update_rounded, size: 64, color: Colors.cyanAccent.withOpacity(0.3)),
                      SizedBox(height: 12),
                      Text(
                        'No recent status updates.\nPull down to refresh.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white54, fontFamily: 'ShareTechMono', fontSize: 12),
                      ),
                    ],
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _fetchStatus,
                  color: Colors.cyanAccent,
                  child: ListView.builder(
                    padding: const EdgeInsets.all(16),
                    itemCount: _statusList.length,
                    itemBuilder: (ctx, i) {
                      final entry = _statusList[i];
                      final items = (entry['items'] as List? ?? []).cast<Map<String, dynamic>>();
                      if (items.isEmpty) return const SizedBox.shrink();
                      final name = entry['name']?.toString() ?? 'Unknown';
                      final last = WAStatus.fromMap(items.last);
                      return _buildStatusCard(name, items.length, last);
                    },
                  ),
                ),
    );
  }

  Widget _buildStatusCard(String name, int count, WAStatus last) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.04),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.cyanAccent.withOpacity(0.2)),
      ),
      child: Row(
        children: [
          Container(
            width: 50, height: 50,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                colors: [Colors.cyanAccent.withOpacity(0.5), Colors.purple.withOpacity(0.3)],
              ),
            ),
            child: Center(
              child: Text(
                name.isNotEmpty ? name[0].toUpperCase() : '?',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18),
              ),
            ),
          ),
          SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(name, style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14, fontFamily: 'MADEEvolveSansEVO')),
                SizedBox(height: 4),
                Row(
                  children: [
                    Icon(
                      last.type == 'image' ? Icons.photo : (last.type == 'video' ? Icons.videocam : Icons.text_snippet),
                      size: 12, color: Colors.cyanAccent.withOpacity(0.7),
                    ),
                    SizedBox(width: 4),
                    Text(
                      last.text.isEmpty ? '[${last.type}]' : last.text,
                      maxLines: 1, overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 11, fontFamily: 'ShareTechMono'),
                    ),
                  ],
                ),
                SizedBox(height: 2),
                Text(
                  '$count update${count > 1 ? 's' : ''} · ${_fmtTime(last.time)}',
                  style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 9, fontFamily: 'ShareTechMono'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _fmtTime(DateTime dt) {
    final diff = DateTime.now().difference(dt);
    if (diff.inMinutes < 1) return 'now';
    if (diff.inHours < 1) return '${diff.inMinutes}m ago';
    if (diff.inDays < 1) return '${diff.inHours}h ago';
    return '${diff.inDays}d ago';
  }
}
