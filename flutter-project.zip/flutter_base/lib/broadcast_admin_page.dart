// broadcast_admin_page.dart — Owner-only broadcast management
//
// Owner bisa:
// - Compose & send broadcast (maintenance/update/info/warning) ke semua user
// - List semua broadcast yang pernah dikirim
// - Delete broadcast
//
// Akses: Admin Panel → tombol "BROADCAST" (orange)

import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

class _BAC {
  // TRANTOR Color Scheme (light, premium fintech — soft yellow + mint + lavender)
  static const bg        = Color(0xFF000000);
  static const bg2       = Color(0xFF0a0a0a);
  static const surface   = Color(0xFF111111);
  static const card      = Color(0xFF111111);
  static const cardHigh  = Color(0xFF222222);
  static const orange    = Color(0xFF222222);
  static const orangeDim = Color(0x1AFF3B30);
  static const purple    = Color(0xFFFF3B30);
  static const text      = Color(0xFFE0E7FF);
  static const textSub   = Color(0xFFa5b4fc);
  static const muted     = Color(0x73E0E7FF);
  static const muted2    = Color(0x38E0E7FF);
  static const border    = Color(0x1AFF3B30);
  static const border2   = Color(0x0FFFFFFF);
  static const danger    = Color(0xFFFF3B30);
  static const success   = Color(0xFFFF3B30);
  static const blue      = Color(0xFFFF3B30);
}

class BroadcastAdminPage extends StatefulWidget {
  final String sessionKey;
  BroadcastAdminPage({super.key, required this.sessionKey});

  @override
  State<BroadcastAdminPage> createState() => _BroadcastAdminPageState();
}

class _BroadcastAdminPageState extends State<BroadcastAdminPage>
    with TickerProviderStateMixin {
  late VideoPlayerController _bgVideoController;
  bool _bgVideoReady = false;

  static const String _baseUrl = "https://api-service.yakuza.biz.id";

  // Form state
  String _selectedType = 'info';
  final _titleController = TextEditingController();
  final _messageController = TextEditingController();
  final _expiryController = TextEditingController(text: '24');
  bool _isSending = false;

  // List state
  List<dynamic> _broadcasts = [];
  bool _isLoadingList = false;
  Timer? _refreshTimer;

  final List<Map<String, dynamic>> _types = [
    {'id': 'maintenance', 'label': 'MAINTENANCE', 'icon': FontAwesomeIcons.screwdriverWrench.data, 'color': _BAC.orange, 'desc': 'Server maintenance / downtime'},
    {'id': 'update',      'label': 'UPDATE',      'icon': FontAwesomeIcons.arrowsRotate.data,     'color': _BAC.blue,   'desc': 'App update available'},
    {'id': 'info',        'label': 'INFO',        'icon': FontAwesomeIcons.circleInfo.data,       'color': _BAC.purple, 'desc': 'General announcement'},
    {'id': 'warning',     'label': 'WARNING',     'icon': FontAwesomeIcons.triangleExclamation.data, 'color': _BAC.danger, 'desc': 'Critical warning'},
  ];

  @override
  void initState() {
    super.initState();
    _initBgVideo();
    _fetchBroadcasts();
    _refreshTimer = Timer.periodic(Duration(seconds: 30), (_) {
      if (mounted) _fetchBroadcasts();
    });
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    _titleController.dispose();
    _messageController.dispose();
    _expiryController.dispose();
    _bgVideoController.dispose();
    super.dispose();
  }

  void _initBgVideo() {
    _bgVideoController = VideoPlayerController.asset('assets/videos/bg_video.mp4')
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _bgVideoReady = true);
          _bgVideoController.play();
          _bgVideoController.setLooping(true);
          _bgVideoController.setVolume(0.0);
        }
      }).catchError((e) {
        debugPrint('BG video error: $e');
      });
  }

  // ── API ───────────────────────────────────────────────────────────────────

  Future<void> _fetchBroadcasts() async {
    if (_isLoadingList) return;
    setState(() => _isLoadingList = true);
    try {
      final res = await http.get(Uri.parse(
        "$_baseUrl/listBroadcasts?key=${widget.sessionKey}",
      )).timeout(Duration(seconds: 10));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          setState(() => _broadcasts = data['broadcasts'] ?? []);
        } else {
          _showSnack(data['message'] ?? 'Gagal memuat', isError: true);
        }
      }
    } catch (_) {
      _showSnack('Connection error', isError: true);
    }
    if (mounted) setState(() => _isLoadingList = false);
  }

  Future<void> _sendBroadcast() async {
    if (_isSending) return;
    final title = _titleController.text.trim();
    final message = _messageController.text.trim();
    final expiryStr = _expiryController.text.trim();

    if (title.isEmpty) {
      _showSnack('Title wajib diisi', isError: true);
      return;
    }
    if (message.isEmpty) {
      _showSnack('Message wajib diisi', isError: true);
      return;
    }

    final expiry = double.tryParse(expiryStr);
    if (expiry == null || expiry < 0) {
      _showSnack('Expiry harus angka >= 0 (0 = permanen)', isError: true);
      return;
    }

    setState(() => _isSending = true);
    try {
      final res = await http.post(
        Uri.parse("$_baseUrl/sendBroadcast"),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'type': _selectedType,
          'title': title,
          'message': message,
          'expiresInHours': expiry,
        }),
      ).timeout(Duration(seconds: 10));

      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        _showSnack('Broadcast terkirim ke semua user!');
        _titleController.clear();
        _messageController.clear();
        _expiryController.text = '24';
        _fetchBroadcasts();
      } else {
        _showSnack(data['message'] ?? 'Gagal kirim broadcast', isError: true);
      }
    } catch (e) {
      _showSnack('Connection error: $e', isError: true);
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  Future<void> _deleteBroadcast(String id) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: _BAC.card,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: _BAC.danger, width: 1),
        ),
        title: Text('Delete Broadcast?',
            style: TextStyle(color: _BAC.text, fontFamily: 'MADEEvolveSansEVO', fontSize: 14)),
        content: Text('Broadcast akan dihapus permanen. Semua user gak akan lihat lagi.',
            style: TextStyle(color: _BAC.muted, fontSize: 12)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text('BATAL', style: TextStyle(color: _BAC.muted)),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: _BAC.danger,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
            ),
            child: Text('HAPUS', style: TextStyle(fontFamily: 'MADEEvolveSansEVO', fontSize: 11)),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    try {
      final res = await http.post(
        Uri.parse("$_baseUrl/deleteBroadcast"),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'key': widget.sessionKey,
          'broadcastId': id,
        }),
      ).timeout(Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        _showSnack('Broadcast dihapus');
        _fetchBroadcasts();
      } else {
        _showSnack(data['message'] ?? 'Gagal hapus', isError: true);
      }
    } catch (_) {
      _showSnack('Connection error', isError: true);
    }
  }

  // ── Helpers ───────────────────────────────────────────────────────────────

  void _showSnack(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg,
          style: TextStyle(color: Colors.white, fontFamily: 'ShareTechMono', fontSize: 12)),
      backgroundColor: isError ? _BAC.danger.withOpacity(0.92) : _BAC.success.withOpacity(0.85),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: const EdgeInsets.all(14),
    ));
  }

  Map<String, dynamic>? _getTypeInfo(String typeId) {
    try {
      return _types.firstWhere((t) => t['id'] == typeId);
    } catch (_) {
      return _types[2]; // default info
    }
  }

  String _formatDate(String? iso) {
    if (iso == null) return '-';
    try {
      final d = DateTime.parse(iso);
      return '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year} ${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
    } catch (_) {
      return iso;
    }
  }

  bool _isExpired(Map<String, dynamic> b) {
    final exp = b['expiresAt'];
    if (exp == null) return false;
    try {
      return DateTime.parse(exp).isBefore(DateTime.now());
    } catch (_) {
      return false;
    }
  }

  // ── BUILD ─────────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        if (_bgVideoReady && _bgVideoController.value.isInitialized)
          SizedBox.expand(
            child: FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: _bgVideoController.value.size.width,
                height: _bgVideoController.value.size.height,
                child: VideoPlayer(_bgVideoController),
              ),
            ),
          )
        else
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFF000000), Color(0xFF0a0a0a), Color(0xFF111111)],
              ),
            ),
          ),
        Container(color: Colors.black.withOpacity(0.65)),
        Scaffold(
          backgroundColor: Colors.transparent,
          extendBodyBehindAppBar: true,
          appBar: AppBar(
            backgroundColor: Colors.transparent,
            elevation: 0,
            leading: Container(
              margin: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                  color: _BAC.card.withOpacity(0.5), shape: BoxShape.circle),
              child: IconButton(
                icon: Icon(Icons.arrow_back_ios_new,
                    color: _BAC.orange, size: 18),
                onPressed: () => Navigator.pop(context),
              ),
            ),
            title: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(FontAwesomeIcons.bullhorn.data, color: _BAC.orange, size: 16),
                SizedBox(width: 8),
                Text("BROADCAST",
                    style: TextStyle(
                        color: _BAC.text,
                        fontFamily: 'MADEEvolveSansEVO',
                        fontWeight: FontWeight.bold,
                        letterSpacing: 2,
                        fontSize: 15)),
              ],
            ),
            centerTitle: true,
            actions: [
              Padding(
                padding: const EdgeInsets.only(right: 8),
                child: GestureDetector(
                  onTap: _isLoadingList ? null : _fetchBroadcasts,
                  child: Container(
                    width: 38, height: 38,
                    decoration: BoxDecoration(
                      color: _BAC.surface,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: _BAC.border2),
                    ),
                    child: Icon(Icons.refresh, color: _BAC.orange, size: 16),
                  ),
                ),
              ),
            ],
            flexibleSpace: ClipRRect(
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                child: Container(color: _BAC.bg.withOpacity(0.4)),
              ),
            ),
          ),
          body: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: Alignment.topCenter,
                radius: 1.4,
                colors: [_BAC.orange.withOpacity(0.06), _BAC.bg.withOpacity(0.0)],
              ),
            ),
            child: SafeArea(
              child: RefreshIndicator(
                color: _BAC.orange,
                onRefresh: _fetchBroadcasts,
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
                  children: [
                    _buildComposeCard(),
                    SizedBox(height: 18),
                    _buildHistoryHeader(),
                    SizedBox(height: 12),
                    if (_isLoadingList && _broadcasts.isEmpty)
                      Center(
                        child: Padding(
                          padding: EdgeInsets.all(40),
                          child: CircularProgressIndicator(color: _BAC.orange, strokeWidth: 2.5),
                        ),
                      )
                    else if (_broadcasts.isEmpty)
                      _buildEmptyState()
                    else
                      ..._broadcasts.map((b) => _buildBroadcastCard(b)),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ── Compose card ──────────────────────────────────────────────────────────
  Widget _buildComposeCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _BAC.card,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _BAC.border, width: 1.5),
        boxShadow: [BoxShadow(color: _BAC.orange.withOpacity(0.08), blurRadius: 20)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              Container(
                width: 36, height: 36,
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [_BAC.orange, _BAC.orangeDim]),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(FontAwesomeIcons.pen.data, color: Colors.white, size: 14),
              ),
              SizedBox(width: 10),
              Text('COMPOSE BROADCAST',
                  style: TextStyle(
                    color: _BAC.orange,
                    fontFamily: 'MADEEvolveSansEVO',
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                  )),
            ],
          ),
          SizedBox(height: 14),
          // Type selector
          Text('TYPE',
              style: TextStyle(
                color: _BAC.muted,
                fontFamily: 'ShareTechMono',
                fontSize: 10,
                letterSpacing: 1,
              )),
          SizedBox(height: 8),
          Row(
            children: _types.map((t) {
              final selected = _selectedType == t['id'];
              final color = t['color'] as Color;
              return Expanded(
                child: GestureDetector(
                  onTap: () => setState(() => _selectedType = t['id']),
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 3),
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    decoration: BoxDecoration(
                      color: selected ? color.withOpacity(0.18) : _BAC.surface,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: selected ? color : _BAC.border2,
                        width: selected ? 1.5 : 1,
                      ),
                    ),
                    child: Column(
                      children: [
                        Icon(t['icon'] as IconData,
                            color: selected ? color : _BAC.muted2, size: 14),
                        SizedBox(height: 4),
                        Text(t['label'] as String,
                            style: TextStyle(
                              color: selected ? color : _BAC.muted,
                              fontFamily: 'MADEEvolveSansEVO',
                              fontSize: 8,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 0.5,
                            )),
                      ],
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
          SizedBox(height: 14),
          // Title input
          _buildInputField(
            controller: _titleController,
            label: 'TITLE',
            hint: 'Judul notifikasi (max 100 char)',
            icon: FontAwesomeIcons.heading.data,
            maxLength: 100,
          ),
          SizedBox(height: 12),
          // Message input
          _buildInputField(
            controller: _messageController,
            label: 'MESSAGE',
            hint: 'Isi pesan notifikasi (max 2000 char)...',
            icon: FontAwesomeIcons.message.data,
            maxLength: 2000,
            maxLines: 4,
          ),
          SizedBox(height: 12),
          // Expiry input
          Row(
            children: [
              Expanded(
                flex: 2,
                child: _buildInputField(
                  controller: _expiryController,
                  label: 'EXPIRY (HOURS)',
                  hint: '24',
                  icon: FontAwesomeIcons.clock.data,
                  keyboardType: TextInputType.number,
                ),
              ),
              SizedBox(width: 10),
              Expanded(
                flex: 3,
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: _BAC.surface,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: _BAC.border2),
                  ),
                  child: Row(
                    children: [
                      Icon(FontAwesomeIcons.circleInfo.data,
                          color: _BAC.orange.withOpacity(0.6), size: 12),
                      SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          '0 = permanen (gak expired). Setelah expiry, notif auto-hide dari user.',
                          style: TextStyle(
                            color: _BAC.muted,
                            fontFamily: 'ShareTechMono',
                            fontSize: 9,
                            height: 1.4,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 16),
          // Send button
          GestureDetector(
            onTap: _isSending ? null : _sendBroadcast,
            child: Container(
              height: 48,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: _isSending
                      ? [_BAC.surface, _BAC.card]
                      : [_BAC.orange, _BAC.orangeDim],
                ),
                borderRadius: BorderRadius.circular(12),
                boxShadow: _isSending
                    ? null
                    : [BoxShadow(color: _BAC.orange.withOpacity(0.3), blurRadius: 16)],
              ),
              child: Center(
                child: _isSending
                    ? SizedBox(
                        width: 20, height: 20,
                        child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                      )
                    : Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(FontAwesomeIcons.paperPlane.data, color: Colors.white, size: 14),
                          SizedBox(width: 8),
                          Text('SEND TO ALL USERS',
                              style: TextStyle(
                                color: Colors.white,
                                fontFamily: 'MADEEvolveSansEVO',
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 2,
                              )),
                        ],
                      ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInputField({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
    int maxLength = 100,
    int maxLines = 1,
    TextInputType keyboardType = TextInputType.text,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: TextStyle(
              color: _BAC.muted,
              fontFamily: 'ShareTechMono',
              fontSize: 10,
              letterSpacing: 1,
            )),
        SizedBox(height: 6),
        Container(
          decoration: BoxDecoration(
            color: _BAC.surface,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: _BAC.border2),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(
            children: [
              Icon(icon, color: _BAC.orange.withOpacity(0.6), size: 14),
              SizedBox(width: 10),
              Expanded(
                child: TextField(
                  controller: controller,
                  style: TextStyle(color: _BAC.text, fontFamily: 'ShareTechMono', fontSize: 12),
                  cursorColor: _BAC.orange,
                  maxLength: maxLength,
                  maxLines: maxLines,
                  keyboardType: keyboardType,
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: hint,
                    hintStyle: TextStyle(color: _BAC.muted2, fontSize: 11, fontFamily: 'ShareTechMono'),
                    counterText: '',
                    contentPadding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ── History ───────────────────────────────────────────────────────────────
  Widget _buildHistoryHeader() {
    return Row(
      children: [
        Container(width: 3, height: 16, color: _BAC.orange),
        SizedBox(width: 8),
        Text('HISTORY (${_broadcasts.length})',
            style: TextStyle(
              color: _BAC.orange,
              fontFamily: 'MADEEvolveSansEVO',
              fontSize: 13,
              fontWeight: FontWeight.bold,
              letterSpacing: 2,
            )),
        Spacer(),
        Text('Newest first',
            style: TextStyle(
              color: _BAC.muted2,
              fontFamily: 'ShareTechMono',
              fontSize: 9,
            )),
      ],
    );
  }

  Widget _buildEmptyState() {
    return Container(
      padding: const EdgeInsets.all(40),
      child: Column(
        children: [
          Icon(FontAwesomeIcons.bullhorn.data, color: _BAC.muted2, size: 40),
          SizedBox(height: 14),
          Text('No broadcasts yet',
              style: TextStyle(color: _BAC.muted, fontFamily: 'ShareTechMono', fontSize: 12)),
          SizedBox(height: 4),
          Text('Broadcast yang lu kirim akan muncul di sini',
              style: TextStyle(color: _BAC.muted2, fontFamily: 'ShareTechMono', fontSize: 10)),
        ],
      ),
    );
  }

  Widget _buildBroadcastCard(Map<String, dynamic> b) {
    final typeInfo = _getTypeInfo(b['type'] as String? ?? 'info');
    final color = typeInfo!['color'] as Color;
    final icon = typeInfo['icon'] as IconData;
    final expired = _isExpired(b);

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _BAC.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: expired ? _BAC.border2 : color.withOpacity(0.3),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              Container(
                width: 32, height: 32,
                decoration: BoxDecoration(
                  color: color.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: color.withOpacity(0.25)),
                ),
                child: Icon(icon, color: color, size: 13),
              ),
              SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      b['title'] as String? ?? '-',
                      style: TextStyle(
                        color: _BAC.text,
                        fontFamily: 'MADEEvolveSansEVO',
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    SizedBox(height: 2),
                    Text(
                      '${typeInfo['label']} • ${_formatDate(b['createdAt'] as String?)}',
                      style: TextStyle(
                        color: _BAC.muted,
                        fontFamily: 'ShareTechMono',
                        fontSize: 9,
                      ),
                    ),
                  ],
                ),
              ),
              if (expired)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: _BAC.muted2,
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text('EXPIRED',
                      style: TextStyle(
                        color: _BAC.muted,
                        fontFamily: 'MADEEvolveSansEVO',
                        fontSize: 7,
                        fontWeight: FontWeight.bold,
                      )),
                )
              else if (b['expiresAt'] == null)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: _BAC.success.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text('PERMANENT',
                      style: TextStyle(
                        color: _BAC.success,
                        fontFamily: 'MADEEvolveSansEVO',
                        fontSize: 7,
                        fontWeight: FontWeight.bold,
                      )),
                ),
            ],
          ),
          SizedBox(height: 10),
          // Message
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: _BAC.surface,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: _BAC.border2),
            ),
            child: Text(
              b['message'] as String? ?? '-',
              style: TextStyle(
                color: _BAC.textSub,
                fontFamily: 'ShareTechMono',
                fontSize: 11,
                height: 1.5,
              ),
            ),
          ),
          SizedBox(height: 8),
          // Footer
          Row(
            children: [
              Icon(FontAwesomeIcons.user.data, color: _BAC.muted2, size: 10),
              SizedBox(width: 4),
              Text('by ${b['createdBy'] ?? '-'}',
                  style: TextStyle(color: _BAC.muted2, fontFamily: 'ShareTechMono', fontSize: 9)),
              Spacer(),
              if (b['expiresAt'] != null && !expired)
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: Text('expires ${_formatDate(b['expiresAt'] as String?)}',
                      style: TextStyle(color: _BAC.muted2, fontFamily: 'ShareTechMono', fontSize: 9)),
                ),
              GestureDetector(
                onTap: () => _deleteBroadcast(b['id'] as String),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: _BAC.danger.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: _BAC.danger.withOpacity(0.3)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(FontAwesomeIcons.trash.data, color: _BAC.danger, size: 10),
                      SizedBox(width: 4),
                      Text('DELETE',
                          style: TextStyle(
                            color: _BAC.danger,
                            fontFamily: 'MADEEvolveSansEVO',
                            fontSize: 9,
                            fontWeight: FontWeight.bold,
                          )),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
