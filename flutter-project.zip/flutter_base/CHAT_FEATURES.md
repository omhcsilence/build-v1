# YakuzaXsilence v5.0 — Private WhatsApp Chat

## What Changed from v4.2

The private chat system has been **completely rewritten** to use real WhatsApp integration (via Baileys library) instead of WebRTC + app-internal DMs.

### Removed (v4.2 → v5.0)
- ❌ WebRTC voice/video calls (`flutter_webrtc` package, `call_screen.dart`)
- ❌ App-to-app DM system (`private_chat.json`, `contacts.json`, `blocks.json`)
- ❌ `flutter_local_notifications` (no longer needed — WhatsApp notifications go through the WA app)
- ❌ `uuid` package (no longer generating call IDs)
- ❌ Old `chat_socket_service.dart`, `notification_service.dart`, `voice_note_service.dart`, `models/message.dart`, `screens/call_screen.dart`, `widgets/voice_note_player.dart` (replaced)

### Added (v5.0)
- ✅ **WhatsApp pairing** via QR code OR pairing code (8-digit)
- ✅ **Real WhatsApp messaging** — chat with your actual WA contacts (text, image, voice note)
- ✅ **Status/story** — view contacts' status + post your own (text, image, video)
- ✅ **WhatsApp call** via `wa.me/<phone>` deep link (opens WhatsApp mobile app)
- ✅ **Owner + VIP only access** (enforced server-side)
- ✅ **1 sender per user, re-pair OK** — re-pairing unpairs the old session first
- ✅ **Hard isolation from bug/spam system** — see below

## Architecture

```
┌──────────────────────────────────────────────────────────┐
│                  BACKEND (index.js)                      │
├──────────────────────────────────────────────────────────┤
│                                                          │
│  Bug/Spam sender pool:                                   │
│    permenmd/<username>/<number>/   ← auth state         │
│    activeConnections = {}           ← in-memory sockets  │
│    /sendBug, /sendBugGroup, ...                          │
│                                                          │
│  ──── COMPLETELY SEPARATE ────                           │
│                                                          │
│  Private WA chat pool:                                   │
│    private_wa/<username>/           ← auth state         │
│    privateSockets = {}               ← in-memory sockets  │
│    /wa-pair, /wa-send, /wa-contacts, /wa-post-status     │
│                                                          │
└──────────────────────────────────────────────────────────┘
```

The two pools **never share state, never share folders, never share in-memory maps**. The bug/spam endpoints read only from `activeConnections` (populated by `permenmd/`). The `/wa-*` endpoints read only from `privateSockets` (populated by `private_wa/`). This is structural isolation — even if a malicious user tries to call `/sendBug` with a private sender ID, the bug system simply has no way to find that sender.

## Backend Endpoints (all require `key` param + role=owner|vip)

| Method | Path | Purpose |
|--------|------|---------|
| POST   | `/wa-pair` | Start pairing (`{method: 'qr'\|'code', phone?}`) |
| GET    | `/wa-pair-status` | Poll pairing status (returns `qr`, `pairingCode`, or `connected`) |
| POST   | `/wa-unpair` | Disconnect + wipe auth state |
| GET    | `/wa-status` | Check if currently paired |
| GET    | `/wa-contacts` | List synced WA contacts |
| GET    | `/wa-chats` | List recent chat partners (with last message preview) |
| GET    | `/wa-chat-history?jid=...` | Get message history with a contact |
| POST   | `/wa-send` | Send a message (`{jid, type, text?, mediaBase64?, ...}`) |
| GET    | `/wa-read-contact?jid=...` | Get profile picture + name for a JID |
| GET    | `/wa-status-list` | List contacts' status updates |
| POST   | `/wa-post-status` | Post a status update (`{type, text?, mediaBase64?}`) |
| GET    | `/wa-call-link?phone=...` | Get a `wa.me/<phone>` deep link |

## New Backend Files (auto-created)

| Path | Purpose |
|------|---------|
| `private_wa/<username>/` | Baileys auth state (creds.json, pre-keys, etc.) |
| `private_wa_index.json` | Map of `username → {phone, jid, name, connectedAt}` |

## Flutter File Layout (changed from v4.2)

```
yakuzaxsilence/
├── pubspec.yaml                            # Removed WebRTC, added qr_flutter
├── index.js                                # +600 lines of WA endpoints
├── android/app/src/main/AndroidManifest.xml  # Added wa.me intent query
└── lib/
    ├── chat_page.dart                      # Rewritten: WhatsApp Web-style
    ├── public_page.dart                    # Restored to original (no changes)
    ├── ddos_page.dart                      # "Live Chat" → "Private WA Chat" (owner+vip only)
    ├── models/
    │   └── wa_models.dart                  # NEW: WAContact, WAMessage, WAChatPreview, WAStatus, WAPairingInfo
    ├── services/
    │   ├── whatsapp_service.dart           # NEW: HTTP + WS for WA chat
    │   └── voice_recorder_service.dart     # NEW: Audio recorder
    ├── widgets/
    │   └── voice_note_player.dart          # NEW: Inline audio player
    └── screens/
        ├── pairing_screen.dart             # NEW: QR + pairing code UI
        └── status_screen.dart              # NEW: View + post status
```

## Setup

### 1. Backend

Replace `index.js` with the new one. No new npm dependencies — uses existing Baileys + express + ws.

```bash
pm2 restart omhc-host-premium   # or your process manager
```

Log on startup:
```
[private-wa] Private WhatsApp chat system loaded (owner+vip only, isolated from bug/spam).
[private-wa] restoring <username>...   (auto-reconnects previously paired sessions)
```

### 2. Flutter

```bash
flutter clean
flutter pub get
flutter run
```

The new dependencies are `record` (already in v4.2) and `qr_flutter` (new). Removed: `flutter_webrtc`, `flutter_local_notifications`, `uuid`.

## Usage Flow

### Pairing (first time)
1. Open "Private WA Chat" (only visible if role = owner or vip)
2. Tap "Start Pairing"
3. Choose method:
   - **QR**: scan with WhatsApp app → Linked Devices → Link a Device
   - **Pairing Code**: enter your phone number → get 8-digit code → type it in WhatsApp app
4. Backend polls `wa-pair-status` every 2s; on `connected`, navigates to chat list

### Messaging
- Search bar: type any phone number (e.g. `62812345678`) → opens chat with that WA contact
- Recent chats: auto-populates as you message contacts (last 200 messages cached per contact)
- Send: text, image (gallery), voice note (hold mic button)
- Real-time: incoming WA messages pushed via WebSocket to your device

### Status
- Tap the camera icon in the header to view contacts' status updates
- Tap "Post" to share your own status (text / image from gallery)

### Call
- Tap the green phone icon in any chat header
- Opens `https://wa.me/<phone>` → redirects to WhatsApp mobile app
- Tap the call button in WhatsApp to actually place the call
- **Note**: Baileys cannot initiate WA calls directly — this is the only way (technical limitation)

### Unpair / Re-pair
- Tap the "link off" icon in the header to unpair
- This wipes `private_wa/<username>/` folder + removes from index
- Pair again with a new number anytime

## Important Limitations

1. **WhatsApp calls via Baileys**: NOT possible — WhatsApp VoIP protocol is proprietary and only available in the official mobile apps. The call button uses `wa.me` deep link as a workaround.
2. **Media download**: Incoming images/voice notes are detected as `[image]` / `[voice]` but the actual media bytes aren't downloaded in this v5.0 — only the metadata. (Adding media download is a straightforward extension; `downloadContentFromMessage` is already imported in the backend.)
3. **Contact sync**: Relies on Baileys' built-in store. May take 10-30s to populate on first connect. Pull-to-refresh to update.
4. **Multi-device**: Each VIP/owner gets exactly ONE paired WhatsApp. Re-pairing unpairs the old one. To have multiple, the user would need to unpair + re-pair every time they want to switch.
5. **Pairing timeout**: QR generation waits 8s; if not scanned in ~60s, Baileys disconnects and you need to start over.

## Migration from v4.2

If you previously installed v4.2:
- **Backend**: `private_chat.json`, `contacts.json`, `blocks.json`, `notifications.json`, `voices/` are now unused. Safe to delete.
- **Flutter**: Old `lib/models/message.dart`, `lib/services/chat_socket_service.dart`, `lib/services/notification_service.dart`, `lib/services/voice_note_service.dart`, `lib/screens/call_screen.dart`, `lib/widgets/voice_note_player.dart` are replaced — delete them before installing v5.0.
- **No data migration**: All previous DM history is lost (as you requested — "replace" option).

The `flutter_webrtc`, `flutter_local_notifications`, and `uuid` packages in `pubspec.yaml` should be removed (already done in this update).
